<?php
include "includes/connect.php";
session_start();
if(isset($_SESSION['email'])){
if(!isset($_POST['order'])){
    header("Location: http://localhost/proj/order.php");
    echo "<script>alert('Order could not be placed')</script>";
    
}

$btype=$_POST['btype'];
$units=$_POST['units'];
$pname=$_POST['pname'];
$datetime=$_POST['datetime'];
$hname=$_POST['hname'];
$haddress=$_POST['haddress'];
$details=$_POST['details'];
$orderbyid=$_SESSION['id'];

$query="INSERT INTO `orders` (`oid`, `btype`, `units`, `pname`, `datetime`, `hname`, `haddress`, `orderbyid`, `details`) VALUES (NULL, '$btype', '$units', '$pname', '$datetime', '$hname', '$haddress', '$orderbyid', '$details')";
$result=mysqli_query($conn,$query);
if(!$result){
    header("Location: http://localhost/proj/order.php");
    echo "<script>alert('Order could not be placed')</script>";
}else{
    header("Location: http://localhost/proj/order.php");
    echo "<script>alert('Order placed successfully')</script>";
}
}else{
    header("Location: http://localhost/proj/order.php");
    echo "<script>alert('Access denied.Login properly')</script>";
    
}
?>