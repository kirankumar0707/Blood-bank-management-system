<?php
    if(isset($_GET['oid'])){
      include ("includes/connect.php");
      session_start();
      if(!isset($_SESSION['email'])){
          echo "<script>alert('Page could not be accessed')</script>";
           header("location: http://localhost/proj/donororder.php");
      }else{
          $oid=$_GET['oid'];
          $query="DELETE FROM orders WHERE oid='$oid'";
          $result=mysqli_query($conn,$query);
          if(!result)
          {
              echo "<script>alert('Couldn\'t delete order details')</script>";
          }else{
              echo "<script>alert('order details deleted successfully')</script>";
          }
          header("location: http://localhost/proj/donororder.php");
}}else{
        echo "<script>alert('Page could not be accessed')</script>";
        header("location: http://localhost/proj/donororder.php");
    }?>
    
   
  
 


