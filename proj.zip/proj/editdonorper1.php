<?php
include 'includes/connect.php';
session_start();
if(!isset($_SESSION['email'])){
    header("Location: http://localhost/proj/index.php");
}
$email=$_SESSION['email'];
$fname=$_POST['fname'];
$mname=$_POST['mname'];
$lname=$_POST['lname'];
$sex=$_POST['sex'];
$btype=$_POST['btype'];
$dob=$_POST['dob'];
$address=$_POST['address'];
$city=$_POST['city'];
$mobile=$_POST['mobile'];
$id=$_SESSION['id'];

$query="UPDATE `donor` SET `fname` = '$fname', `mname` = '$mname', `lname` ='$lname', `sex` = '$sex', `btype` = '$btype', `dob` = '$dob', `address` = '$address', `city` = '$city', `mobile` = '$mobile' WHERE `id` = '$id'";

$result=mysqli_query($conn,$query);
if(!$result){
    echo "<script>alert('Could not be registered .Try again')</script>";
}else{

    header("Location: http://localhost/proj/home.php");
}
?>