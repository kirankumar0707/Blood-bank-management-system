<?php
      include ("includes/connect.php");
      session_start();
      if(!isset($_SESSION['email'])){
          echo "<script>alert('Page could not be accessed')</script>";
           header("location: http://localhost/proj/donororder.php");
      }else{
          $oid=$_POST['oid'];
          $btype=$_POST['btype'];
          $units=$_POST['units'];
          $pname=$_POST['pname'];
          $datetime=$_POST['datetime'];
          $hname=$_POST['hname'];
          $haddress=$_POST['haddress'];
          $details=$_POST['details'];
          
          $query="UPDATE `orders` SET `btype` = '$btype', `units` = '$units', `pname` = '$pname', `datetime` = '$datetime', `hname` = '$hname', `haddress` = '$haddress', `details` = '$details' WHERE `oid` = '$oid'";
          $result=mysqli_query($conn,$query);
          if(!$result){
              echo "<script>alert('Couldn\'t edit Order details')</script>";
          }else{
              echo "<script>alert('Order details edited successfully')</script>";
          }
       header("location: http://localhost/proj/donororder.php");   
        
    }?>