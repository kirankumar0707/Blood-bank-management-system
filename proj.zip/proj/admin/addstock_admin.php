<?php
      include ("includes/connect.php");
      session_start();
      if(!isset($_SESSION['uname'])){
          echo "<script>alert('Page could not be accessed')</script>";
           header("location: http://localhost/proj/admin/stock_admin.php");
      }else{
          $query="SELECT bbname FROM bbank";
          $result=mysqli_query($conn,$query);
         
    }?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="bloodbankmanagement.com">
    <meta name="author" content="bloodbank.com">
    <title>Blood Bank Admin Management</title>
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/custom.css" rel="stylesheet">
    <link href="http://netdna.bootstrapcdn.com/font-awesome/4.0.3/css/font-awesome.css" rel="stylesheet">
    <link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css'>
    <link href='http://fonts.googleapis.com/css?family=Oswald' rel='stylesheet' type='text/css'>
  </head>
  <body>
    <!-- Fixed navbar -->
    <div class="navbar navbar-default navbar-fixed-top" role="navigation">
      <div class="container">
        <div class="navbar-header">
          <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
          <a class="navbar-brand" href="#">Blood Bank Admin Management</a>
        </div>
        <div class="navbar-collapse collapse">
          <ul class="nav navbar-nav navbar-right">
            <li><a href="home_admin.php">Home</a></li>
            <li><a href="donor_admin.php">Reg. Donors</a></li>  
            <li class="active"><a href="stock_admin.php">Stock</a></li>     
            <li><a href="orders_admin.php">Orders</a></li>          
            <li><a href="contact_admin.php">Messages</a></li>
            <li><a href="logout_admin.php">Logout</a></li>
          </ul>
        </div><!--/.nav-collapse -->
      </div>
    </div>
    
    
    <div class="panel panel-default">
        <div class="panel-heading">
            <h3 class="panel-title">Add New Stock Details</h3>
        </div>
        <form class="form-horizontal" role="form" method="post" action="addstock1_admin.php">
        <div class="form-group">
            <label class="col-sm-3">Stock-ID</label>
                <div class="col-sm-6">
                    <input class="form-control" name="sid" type="number" placeholder="Enter unique stock-id" required>
                </div>
        </div>
        <div class="form-group">
            <label class="col-sm-3">Blood type</label>
            <div class="col-sm-6">
                <select name="btype" class="form-control" required>
                    <option value="O+">O+</option>
                    <option value="O-">O-</option>
                    <option value="A+">A+</option>
                    <option value="A-">A-</option>
                    <option value="B+">B+</option>
                    <option value="B-">B-</option>
                    <option value="AB+">AB+</option>
                    <option value="AB-">AB-</option>
                </select>
            </div>
        </div>
        <div class="form-group">
           <label class="col-sm-3">Donor-ID</label>
           <div class="col-sm-6">
               <input class="form-control" name="don_id" type="number" placeholder="Can be empty">
           </div>
        </div>
        <div class="form-group">
           <label class="col-sm-3">Date of Collection</label>
           <div class="col-sm-6">
               <input class="form-control" name="coll_date" type="date" required>
           </div>
        </div>
        <div class="form-group">
           <label class="col-sm-3">Blood Bank</label>
           <div class="col-sm-6">
              <select name="bbname" class="form-control">
                   <?php while($d=mysqli_fetch_assoc($result)):?>
                        <option value="<?= $d['bbname']; ?>"><?= $d['bbname']?></option>
                    <?php endwhile; ?>  
              </select>
           </div>
        </div>
        <div class="form-group">
           <label class="col-sm-3">Description</label>
           <div class="col-sm-6">
               <input class="form-control" type="text" name="description">
           </div>
        </div><br>
        <div class="panel-footer">
            <button type="submit" class="btn btn-primary" name="edit">Add</button>
            <a type="btn btn-default" href="stock_admin.php">Back</a>
        </div>
        </form>
    </div> 
	
	<!-- Fixed footer -->
    <div class="navbar navbar-inverse navbar-fixed-bottom" role="navigation">
    	<div class="container">
    		<div class="navbar-text pull-left">
                <p>Project by: <b>KIRAN KUMAR.A</b> & <b>KARTHIK.T</b></p>
    		</div>
    		<div class="navbar-text pull-right">
    			<a href="#"><i class="fa fa-facebook-square fa-2x"></i></a>
    			<a href="#"><i class="fa fa-twitter fa-2x"></i></a>
    			<a href="#"><i class="fa fa-google-plus fa-2x"></i></a>
    		</div>
    	</div>
    </div>
    
   
    
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.0/jquery.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
  </body>
</html>