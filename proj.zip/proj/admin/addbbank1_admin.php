<?php
      include ("includes/connect.php");
      session_start();
      if(!isset($_SESSION['uname'])){
          echo "<script>alert('Page could not be accessed')</script>";
           header("location: http://localhost/proj/admin/addbbank_admin.php");
      }else{
          $bbname=$_POST['bbname'];
          $baddress=$_POST['baddress'];
          $bemail=$_POST['bemail'];
          $bphone=$_POST['bphone'];
          $query="INSERT INTO `bbank` (`bbname`, `baddress`, `bemail`, `bphone`) VALUES ('$bbname', '$baddress', '$bemail', '$bphone')";
          $result=mysqli_query($conn,$query);
          if(!$result){
              echo "<script>alert('Couldn\'t edit stock details')</script>";
          }else{
              echo "<script>alert('Stock details edited successfully')</script>";
          }
        header("location: http://localhost/proj/admin/home_admin.php");   
        
    }?>