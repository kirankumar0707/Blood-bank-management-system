<?php
    if(isset($_GET['bbname'])){
      include ("includes/connect.php");
      session_start();
      if(!isset($_SESSION['uname'])){
          echo "<script>alert('Page could not be accessed')</script>";
           header("location: http://localhost/proj/admin/home_admin.php");
      }else{
          $bbname=$_GET['bbname'];
          $query="DELETE FROM bbank WHERE bbname='$bbname'";
          $result=mysqli_query($conn,$query);
          if(!result)
          {
              echo "<script>alert('Couldn\'t delete blood bank details')</script>";
          }else{
              echo "<script>alert('blood bank details deleted successfully')</script>";
          }
          header("location: http://localhost/proj/admin/home_admin.php");
}}else{
        echo "<script>alert('Page could not be accessed')</script>";
        header("location: http://localhost/proj/admin/home_admin.php");
    }?>
    
   
  
 


