<?php
    if(isset($_GET['sid'])){
      include ("includes/connect.php");
      session_start();
      if(!isset($_SESSION['uname'])){
          echo "<script>alert('Page could not be accessed')</script>";
           header("location: http://localhost/proj/admin/stock_admin.php");
      }else{
          $sid=$_GET['sid'];
          $query="DELETE FROM stock WHERE sid='$sid'";
          $result=mysqli_query($conn,$query);
          if(!result)
          {
              echo "<script>alert('Couldn\'t delete stock details')</script>";
          }else{
              echo "<script>alert('stock details deleted successfully')</script>";
          }
          header("location: http://localhost/proj/admin/stock_admin.php");
}}else{
        echo "<script>alert('Page could not be accessed')</script>";
        header("location: http://localhost/proj/admin/stock_admin.php");
    }?>
    
   
  
 


