<?php
$conn=mysqli_connect("localhost","root","") or die("No connection possible");
mysqli_select_db($conn,"bbms") or die ("The database does not exist");


?>
