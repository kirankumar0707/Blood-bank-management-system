<?php
      include ("includes/connect.php");
      session_start();
      if(!isset($_SESSION['uname'])){
          echo "<script>alert('Page could not be accessed')</script>";
           header("location: http://localhost/proj/admin/stock_admin.php");
      }else{
          $sid=$_POST['sid'];
          $btype=$_POST['btype'];
          $don_id=$_POST['don_id'];
          $coll_date=$_POST['coll_date'];
          $bbname=$_POST['bbname'];
          $description=$_POST['description'];
          $query="UPDATE `stock` SET `bbname` = '$bbname', `btype` = '$btype', `don_id` = '$don_id', `coll_date` = '$coll_date', `description` = '$description' WHERE `stock`.`sid` = '$sid'";
          $result=mysqli_query($conn,$query);
          if(!$result){
              echo "<script>alert('Couldn\'t edit stock details')</script>";
          }else{
              echo "<script>alert('Stock details edited successfully')</script>";
          }
       header("location: http://localhost/proj/admin/stock_admin.php");   
        
    }?>