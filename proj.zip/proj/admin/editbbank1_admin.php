<?php
      include ("includes/connect.php");
      session_start();
      if(!isset($_SESSION['uname'])){
          echo "<script>alert('Page could not be accessed')</script>";
           header("location: http://localhost/proj/admin/home_admin.php");
      }else{
          $oldbbname=$_POST['oldbbname'];
          $bid=$_POST['bid'];
          $bbname=$_POST['bbname'];
          $baddress=$_POST['baddress'];
          $bemail=$_POST['bemail'];
          $bphone=$_POST['bphone'];
          $query="UPDATE `bbank` SET `bbname` = '$bbname', `baddress` = '$baddress', `bemail` = '$bemail', `bphone` = '$bphone' WHERE `bbname` = '$oldbbname'";
          $result=mysqli_query($conn,$query);
          if(!$result){
              echo "<script>alert('Couldn\'t edit Blood Bank details')</script>";
          }else{
              echo "<script>alert('Bloood Bank details edited successfully')</script>";
          }
        header("location: http://localhost/proj/admin/home_admin.php");   
        
    }?>