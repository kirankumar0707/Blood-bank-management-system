-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 30, 2018 at 12:59 PM
-- Server version: 10.1.36-MariaDB
-- PHP Version: 7.2.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `bbms`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `aid` int(8) NOT NULL,
  `uname` varchar(20) NOT NULL,
  `password` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`aid`, `uname`, `password`) VALUES
(12340001, 'kirankumar', '123456'),
(12340002, 'kirangowda', '987654'),
(12340003, 'karthik', 'karthi123');

-- --------------------------------------------------------

--
-- Table structure for table `bbank`
--

CREATE TABLE `bbank` (
  `bbname` varchar(20) NOT NULL,
  `bid` int(5) NOT NULL,
  `baddress` varchar(100) NOT NULL,
  `bemail` varchar(40) NOT NULL,
  `bphone` bigint(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `bbank`
--

INSERT INTO `bbank` (`bbname`, `bid`, `baddress`, `bemail`, `bphone`) VALUES
('bbank hubbali', 1006, 'hubbali, karnataka', 'bbankhubbali@gmail.com', 87459632),
('bbank malleshwaram', 1005, 'malleshwaram, bangalore', 'bbankmalleshwaram@gmail.com', 45698723),
('bbank mandya', 1008, 'mandya,karnataka', 'bbankmandya@gmail.com', 45987563),
('bbank mysore', 1007, 'mysore, karnataka', 'bbankmysore@gmail.com', 45698237),
('bbank peenya', 1001, 'peenya industrial area, peenya,bangalore', 'bbankpeenya@gmail.com', 23658947),
('bbank rajajinagar', 1002, 'ESIC hospital,rajajinagar,bangalore', 'bbankrajajinagar@gmail.com', 45698231),
('bbank rtnagar', 1004, 'RT nagar, bangalore', 'bbankrtnagar@gmail.com', 36547892),
('bbank vijayanagar', 1003, 'vijaynagar,bangalore', 'bbankvijayanagar@gmail.com', 25896314);

-- --------------------------------------------------------

--
-- Table structure for table `contact`
--

CREATE TABLE `contact` (
  `msgid` int(5) NOT NULL,
  `id` int(8) NOT NULL,
  `name` varchar(40) NOT NULL,
  `email` varchar(50) NOT NULL,
  `subject` varchar(50) NOT NULL,
  `msg` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `contact`
--

INSERT INTO `contact` (`msgid`, `id`, `name`, `email`, `subject`, `msg`) VALUES
(2, 20180054, 'yogesh', 'yogesh@gmail.com', 'stock', 'amount of blood sent was not sufficient'),
(3, 20180048, 'Manjesh', 'manjesh@gmail.com', 'blood bank', 'blood bank doesnt respond well on call.bad customer care'),
(5, 20180046, 'teja a', 'teja@gmail.com', 'improve order delivery time', 'blood was not delivered in time.patient died'),
(6, 20180058, 'Sarada', 'sarada@gmail.com', 'No stock', 'Blood isnt available at mysore blood bank'),
(8, 20180050, 'manoj s', 'manoj@gmail.com', 'order', 'blood is not sent to the patient.Patient critical'),
(10, 20180055, 'Ravi N', 'ravi@gmail.com', 'improper care on delivery', 'The blood delivered was not properly sealed.'),
(11, 20180001, 'kiran gowda ', 'kirankumar070798@gmail.com', 'test', 'test');

-- --------------------------------------------------------

--
-- Table structure for table `donor`
--

CREATE TABLE `donor` (
  `id` int(8) NOT NULL,
  `fname` varchar(50) NOT NULL,
  `mname` varchar(50) DEFAULT NULL,
  `lname` varchar(50) NOT NULL,
  `sex` varchar(6) NOT NULL,
  `btype` varchar(10) NOT NULL,
  `dob` date NOT NULL,
  `address` varchar(100) NOT NULL,
  `city` varchar(50) NOT NULL,
  `mobile` bigint(10) NOT NULL,
  `email` varchar(50) NOT NULL,
  `password` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `donor`
--

INSERT INTO `donor` (`id`, `fname`, `mname`, `lname`, `sex`, `btype`, `dob`, `address`, `city`, `mobile`, `email`, `password`) VALUES
(20180001, 'kiran', 'kumar', 'gowda ', 'male', 'A+', '1998-07-07', 'laggere,bangalore', 'bangalore', 9738275099, 'kirankumar070798@gmail.com', '123456'),
(20180002, 'Sunil', 'kumar', 'gowda', 'male', 'O+', '1998-06-16', 'laggere,bangalore', 'bangalore', 123456789, 'sunikumar@gmail.com', '123456'),
(20180043, 'murali', 'gowda', 'v', 'male', 'O+', '1997-12-20', '#5,2ND MAIN,1ST CROSS,CHOWDESHWARI TEMPLE ROAD,CHOWDESHWARI NAGAR, LAGGERE,', 'bangalore', 9900258965, 'murali@gmail', '123456'),
(20180044, 'karthik', 't', 't', 'male', 'A-', '1998-10-28', 'SIDDARTHA mens hostel', 'banglore', 7816840695, 'karthik@gmail', '123456'),
(20180046, 'teja', 'm', 'a', 'male', 'B+', '1998-01-23', 'laggere,bangalore', 'bangalore', 8892461673, 'teja@gmail.com', '123456'),
(20180047, 'Keerthana', 'A', 'Gowda', 'female', 'O+', '1999-09-22', '#2,2ND MAIN,1ST CROSS,CHOWDESHWARI TEMPLE ROAD', 'bangalore', 9875642312, 'keerthana@gmail.com', '123456'),
(20180048, 'Manjesh', 'm', 'k', 'male', 'B-', '1995-02-03', 'near ESIC hospital,rajajinagar,', 'Bangalore', 8965321475, 'manjesh@gmail.com', '123456'),
(20180049, 'Ramesh', 't', 'a', 'male', 'AB-', '1987-12-04', 'vijayanagar', 'bangalore', 7896541230, 'ramesh@gmail.com', '123456'),
(20180050, 'Manoj', 'k', 's', 'male', 'O-', '1997-05-06', 'rajivgandhi nagar', 'bangalore', 8745321698, 'manoj@gmail.com', '123456'),
(20180051, 'Rakesh', 's', 'p', 'male', 'AB-', '1997-05-09', 'parvathi nagar,laggere', 'bangalore', 7458963215, 'rakesh@gmail.com', '123456'),
(20180052, 'bharathi', 'd', 'r', 'female', 'A+', '1974-01-01', '#2,2ND MAIN,1ST CROSS,CHOWDESHWARI TEMPLE ROAD', 'CHOWDESHWARI NAGAR, LAGGERE,', 9739935762, 'bharathidr@gmail.com', '123456'),
(20180053, 'Rajesh', 'g', 'k', 'male', 'A-', '1998-08-10', 'R T nagar', 'bangalore', 8745963215, 'rajesh@gmail.com', '123456'),
(20180054, 'Yogesh', 'b', 't', 'male', 'AB-', '1984-01-03', 'sangolli rayanna nagar', 'tumkur', 8796542589, 'yogesh@gmail.com', '123456'),
(20180055, 'Ravi', 'J', 'N', 'male', 'B-', '1993-02-02', 'bgt palya,near toll gate,sira', 'tumkur', 9874258974, 'ravi@gmail.com', '123456'),
(20180056, 'manukumar', 'j', 'n', 'male', 'O-', '1994-05-04', 'chenamma nagar', 'hubballi', 6987452135, 'manukumar@gmail.com', '123456'),
(20180057, 'sathish', 'g', 'gowda', 'male', 'AB+', '2018-02-07', 'anjali nagar', 'mysore', 8745963214, 'sathish@gmail.com', '123456'),
(20180058, 'sarada', 's', 'gowda', 'male', 'B+', '1981-02-03', 'anjali nagar', 'mysore', 8745963215, 'sarada@gmail.com', '123456'),
(20180059, 'ki', 'ki', 'd', 'male', 'O+', '1998-11-21', '#2,2ND MAIN,1ST CROSS,', 'mysore', 1478523692, 'qwerty@1.com', '123123');

-- --------------------------------------------------------

--
-- Table structure for table `donormed`
--

CREATE TABLE `donormed` (
  `no` int(5) NOT NULL,
  `id` int(8) NOT NULL,
  `don_date` date NOT NULL,
  `stats` varchar(20) NOT NULL,
  `temp` varchar(20) NOT NULL,
  `pulse` varchar(20) NOT NULL,
  `bp` varchar(20) NOT NULL,
  `weight` varchar(20) NOT NULL,
  `hemoglobin` varchar(20) NOT NULL,
  `hbsag` varchar(20) NOT NULL,
  `aids` varchar(20) NOT NULL,
  `malaria_smear` varchar(20) NOT NULL,
  `hematocrit` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `donormed`
--

INSERT INTO `donormed` (`no`, `id`, `don_date`, `stats`, `temp`, `pulse`, `bp`, `weight`, `hemoglobin`, `hbsag`, `aids`, `malaria_smear`, `hematocrit`) VALUES
(1, 20180001, '2016-02-07', 'normal', '35', '65', '80/122', '76', '16-18 gm/dl', 'negative', 'negative', 'negative', '45%'),
(2, 20180002, '2018-10-02', 'NORMAL', '35', '65', '80/130', '56', '16-18 gm/dl', 'negative', 'negative', 'negative', '42-58 %'),
(5, 20180043, '2012-12-20', 'normal', '35', '62', '80/120', '56', '16-18 gm/dl', 'negative', 'negative', 'negative', '45%'),
(6, 20180044, '2018-11-10', 'normal', '35', '65', '80/120', '63', '16-18 gm/dl', 'negative', 'negative', 'negative', '45%'),
(7, 20180046, '2016-02-02', 'normal', '30', '65', '80/125', '60', '16-18 gm/dl', 'negative', 'negative', 'negative', '45%'),
(8, 20180047, '2016-05-22', 'normal', '36', '60', '90/123', '52', '16-18 gm/dl', 'negative', 'negative', 'negative', '42% - 63%'),
(9, 20180048, '1996-02-25', 'normal', '27', '72', '80/125', '82', '15-19 gm/dl', 'unknown', 'unknown', 'unknown', '45%'),
(10, 20180049, '2015-02-02', 'feverish', '32', '75', '90/120', '68', '16-20 gm/dl', 'positive', 'negative', 'positive', '42% - 65%'),
(11, 20180050, '2017-03-02', 'normal', '29', '70', '80/122', '62', '16-18 gm/dl', 'negative', 'negative', 'negative', '42% - 65%'),
(12, 20180051, '2018-05-15', 'normal', '29', '68', '78/125', '71', '16-18 gm/dl', 'negative', 'negative', 'negative', '48% - 65%'),
(13, 20180052, '2005-06-05', 'normal', '30', '73', '80/120', '62', '16-18 gm/dl', 'negative', 'negative', 'negative', '48% - 65%'),
(14, 20180053, '2018-04-09', 'normal', '31', '71', '80/120', '81', '17-19 gm/dl', 'negative', 'negative', 'negative', '42% - 63%'),
(15, 20180054, '2016-02-25', 'normal', '28', '76', '90/120', '65', '14-18 gm/dl', 'negative', 'negative', 'negative', '42% - 63%'),
(16, 20180055, '2014-08-03', 'normal', '30', '69', '80/120', '64', '16-18 gm/dl', 'negative', 'negative', 'negative', '42% - 63%'),
(17, 20180056, '2016-06-05', 'normal', '28', '78', '89/130', '72', '16-18 gm/dl', 'negative', 'negative', 'negative', '48% - 65%'),
(18, 20180057, '2017-09-29', 'normal', '31', '75', '80/120', '74', '16-18 gm/dl', 'negative', 'negative', 'negative', '42% - 63%'),
(19, 20180058, '2014-11-24', 'normal', '28', '72', '80/120', '65', '16-18 gm/dl', 'negative', 'negative', 'negative', '48% - 65%'),
(20, 20180059, '2017-12-11', 'normal', '27', '72', '80/120', '65', '16-18 gm/dl', 'negative', 'negative', 'negative', '42% - 63%');

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `oid` int(8) NOT NULL,
  `btype` varchar(10) NOT NULL,
  `units` int(5) NOT NULL,
  `pname` varchar(20) NOT NULL,
  `datetime` datetime NOT NULL,
  `hname` varchar(30) NOT NULL,
  `haddress` varchar(100) NOT NULL,
  `orderbyid` int(8) NOT NULL,
  `details` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`oid`, `btype`, `units`, `pname`, `datetime`, `hname`, `haddress`, `orderbyid`, `details`) VALUES
(1006, 'A-', 3, 'harish', '2018-11-29 08:00:00', 'people tree hospital', 'gorguntpalya,yeshwantpur', 20180050, NULL),
(1008, 'B-', 5, 'Suresh', '2018-12-05 17:00:00', 'ESIC hospital', 'Gorgunte palya', 20180044, NULL),
(1009, 'AB+', 4, 'kishore', '2018-11-30 03:30:00', 'jayadeva', 'kormangala', 20180058, NULL),
(1011, 'O-', 1, 'sanjana', '2018-11-23 11:00:00', 'pegasus hospital', 'kamakshi palya,bangalore', 20180053, 'deliver asap .contact:8974562158'),
(1012, 'B+', 4, 'anand', '2018-11-26 17:00:00', 'spandana', 'rajgopal nagar,peenya,bangalore', 20180046, NULL),
(1015, 'AB-', 4, 'akshay', '2018-12-07 05:00:00', 'Ramaiah hospital', 'new bell road', 20180050, 'Patient in C ward.'),
(1016, 'B+', 5, 'Sanjay', '2018-11-12 10:00:00', 'Ramaiah Hospital.', 'New BEL Road,Bangalore', 20180001, 'deliver to patients mother.contact:9857462251'),
(1017, 'AB-', 4, 'Harsha', '2018-12-16 10:00:00', 'Ramaiah Hospital', 'New BEL Road,Bangalore', 20180001, ''),
(1018, 'B-', 3, 'Harshitha', '2018-12-29 10:00:00', 'Spandana hospital', 'Kamakshipalya bangalore', 20180001, '');

-- --------------------------------------------------------

--
-- Table structure for table `stock`
--

CREATE TABLE `stock` (
  `sid` int(8) NOT NULL,
  `bbname` varchar(50) NOT NULL,
  `btype` varchar(10) NOT NULL,
  `don_id` int(8) DEFAULT NULL,
  `coll_date` date NOT NULL,
  `description` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `stock`
--

INSERT INTO `stock` (`sid`, `bbname`, `btype`, `don_id`, `coll_date`, `description`) VALUES
(12002, 'bbank rajajinagar', 'A+', 20180001, '2018-11-09', 'this is to be sent to the patient immediately'),
(12003, 'bbank peenya', 'O+', 20180043, '2018-10-21', 'for order id 1005'),
(12004, 'bbank rajajinagar', 'O+', 20180002, '2018-10-23', 'for order id 1005'),
(12005, 'bbank malleshwaram', 'A+', 20180001, '2018-11-04', ''),
(12006, 'bbank peenya', 'A+', 20180001, '2018-11-01', ''),
(12007, 'bbank peenya', 'B+', 20180046, '2018-10-29', ''),
(12008, 'bbank malleshwaram', 'O-', 20180050, '2018-10-03', ''),
(12009, 'bbank mysore', 'B-', 20180046, '2018-11-11', 'this should be used immediately'),
(12010, 'bbank rajajinagar', 'O+', 20180043, '2018-11-12', ''),
(12012, 'bbank peenya', 'A-', 20180053, '2018-11-12', 'for order id 1006'),
(12014, 'bbank mysore', 'B-', 20180048, '2018-10-30', ''),
(12015, 'bbank peenya', 'A-', 20180044, '2018-11-02', ''),
(12016, 'bbank hubbali', 'AB-', 20180051, '2018-11-01', ''),
(12017, 'bbank peenya', 'B+', 20180058, '2018-10-23', ''),
(12018, 'bbank rajajinagar', 'O+', 20180043, '2018-11-20', ''),
(12020, 'bbank vijayanagar', 'B+', 20180046, '2018-11-11', ''),
(12021, 'bbank mysore', 'AB+', 20180001, '2018-12-20', ''),
(12022, 'bbank mysore', 'B+', 20180058, '2018-10-15', ''),
(12023, 'bbank rajajinagar', 'O+', 20180043, '2018-11-09', ''),
(12024, 'bbank rtnagar', 'O-', 20180056, '2018-10-29', ''),
(12025, 'bbank vijayanagar', 'A+', 20180052, '0000-00-00', ''),
(12027, 'bbank peenya', 'O+', 20180004, '2018-11-01', ''),
(12028, 'bbank mysore', 'AB+', 20180057, '2018-10-10', ''),
(12029, 'bbank hubbali', 'AB-', 20180054, '2018-11-11', ''),
(12030, 'bbank mysore', 'B-', 20180055, '2018-10-23', ''),
(12031, 'bbank peenya', 'O+', 20180047, '2018-11-03', ''),
(12032, 'bbank malleshwaram', 'A-', 2018053, '2018-10-26', ''),
(12035, 'bbank rajajinagar', 'O+', 20180002, '2018-11-23', ''),
(12037, 'bbank peenya', 'AB+', 20180057, '2018-11-12', ''),
(12038, 'bbank peenya', 'O-', 20180050, '2018-11-04', ''),
(12046, 'bbank mysore', 'AB+', 20180057, '2018-11-01', ''),
(12053, 'bbank peenya', 'B+', 20180046, '2018-11-05', ''),
(12059, 'bbank peenya', 'AB-', 20180054, '2018-11-16', ''),
(12061, 'bbank peenya', 'B-', 20180048, '2018-11-07', ''),
(12072, 'bbank peenya', 'O+', 20180058, '2018-10-20', ''),
(12079, 'bbank peenya', 'A+', 20180052, '2018-10-19', '');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`aid`),
  ADD UNIQUE KEY `uname` (`uname`);

--
-- Indexes for table `bbank`
--
ALTER TABLE `bbank`
  ADD PRIMARY KEY (`bbname`),
  ADD UNIQUE KEY `unique` (`bid`);

--
-- Indexes for table `contact`
--
ALTER TABLE `contact`
  ADD PRIMARY KEY (`msgid`),
  ADD KEY `id` (`id`);

--
-- Indexes for table `donor`
--
ALTER TABLE `donor`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `donormed`
--
ALTER TABLE `donormed`
  ADD PRIMARY KEY (`no`),
  ADD KEY `id` (`id`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`oid`),
  ADD KEY `orderbyid` (`orderbyid`);

--
-- Indexes for table `stock`
--
ALTER TABLE `stock`
  ADD PRIMARY KEY (`sid`),
  ADD KEY `bbname` (`bbname`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `aid` int(8) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12340004;

--
-- AUTO_INCREMENT for table `bbank`
--
ALTER TABLE `bbank`
  MODIFY `bid` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1009;

--
-- AUTO_INCREMENT for table `contact`
--
ALTER TABLE `contact`
  MODIFY `msgid` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `donor`
--
ALTER TABLE `donor`
  MODIFY `id` int(8) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20180060;

--
-- AUTO_INCREMENT for table `donormed`
--
ALTER TABLE `donormed`
  MODIFY `no` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `oid` int(8) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1019;

--
-- AUTO_INCREMENT for table `stock`
--
ALTER TABLE `stock`
  MODIFY `sid` int(8) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12080;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `contact`
--
ALTER TABLE `contact`
  ADD CONSTRAINT `contact_ibfk_1` FOREIGN KEY (`id`) REFERENCES `donor` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `donormed`
--
ALTER TABLE `donormed`
  ADD CONSTRAINT `donormed_ibfk_1` FOREIGN KEY (`id`) REFERENCES `donor` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `orders`
--
ALTER TABLE `orders`
  ADD CONSTRAINT `orders_ibfk_1` FOREIGN KEY (`orderbyid`) REFERENCES `donor` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `stock`
--
ALTER TABLE `stock`
  ADD CONSTRAINT `stock_ibfk_1` FOREIGN KEY (`bbname`) REFERENCES `bbank` (`bbname`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
