<?php
      include 'includes/connect.php';
      session_start();
      if(!isset($_SESSION['email'])){
          echo "<script>alert('Could not be accessed.Login again')</script>";
           header("location: http://localhost/proj/index.php");
      }else{
          $id=$_SESSION['id'];
          $query="SELECT * FROM orders WHERE orderbyid='$id'";
          $result=mysqli_query($conn,$query);
      }
?>
          
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="bloodbankmanagement.com">
    <meta name="author" content="bloodbank.com">
    <title>Blood Bank Management</title>
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/custom.css" rel="stylesheet">
    <link href="http://netdna.bootstrapcdn.com/font-awesome/4.0.3/css/font-awesome.css" rel="stylesheet">
    <link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css'>
    <link href='http://fonts.googleapis.com/css?family=Oswald' rel='stylesheet' type='text/css'>
  </head>
  <body>
    <!-- Fixed navbar -->
    <div class="navbar navbar-default navbar-fixed-top" role="navigation">
      <div class="container">
        <div class="navbar-header">
          <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
          <a class="navbar-brand" href="#">Blood Bank Management</a>
        </div>
        <div class="navbar-collapse collapse">
          <ul class="nav navbar-nav navbar-right">
            <li><a href="home.php">My Profile</a></li>       
            <li><a href="order.php">Order</a></li>
            <li class="active"><a href="donororder.php">My Orders</a></li>          
            <li><a href="#contact" data-toggle="modal">Contact</a></li>
            <li><a href="logout.php">Logout</a></li>
          </ul>
        </div><!--/.nav-collapse -->
      </div>
    </div>
   
          
          <div class="panel panel-default">
        <div class="panel-heading">
            <h2 class="panel-title">MY ORDERS</h2>
        </div>
        <table class="table table-bordered table-striped">
            <thead>
                <td>ORDER ID</td>
                <td>Blood Type</td>
                <td>No. of units</td>
                <td>Patient Name</td>
                <td>Required On</td>
                <td>Hospital Name</td>
                <td>Hospital Address</td>
                <td>Details</td>
            </thead>
            <?php while($d=mysqli_fetch_array($result)):?>
          
                <tr>
                    <td><?= $d['oid']; ?></td>
                    <td><?= $d['btype']; ?></td>
                    <td><?= $d['units']; ?></td>
                    <td><?= $d['pname']; ?></td>
                    <td><?= $d['datetime']; ?></td>
                    <td><?= $d['hname']; ?></td>
                    <td><?= $d['haddress']; ?></td>
                    <td><?= wordwrap($d['details'],30,'<br>'); ?></td>
                    <td><a href="editorder.php?oid=<?= $d['oid']?>">Edit</a></td>
                    <td><a href="deleteorder.php?oid=<?= $d['oid']?>">Delete</a></td>
                </tr>
           
            <?php endwhile; ?>
        </table>
    </div> 
         
                   
	<!-- Fixed footer -->
    <div class="navbar navbar-inverse navbar-fixed-bottom" role="navigation">
    	<div class="container">
    		<div class="navbar-text pull-left">
    			<p>Project by: <b>KIRAN KUMAR.A</b> & <b>KARTHIK.T</b></p>
    		</div>
    		<div class="navbar-text pull-right">
    			<a href="#"><i class="fa fa-facebook-square fa-2x"></i></a>
    			<a href="#"><i class="fa fa-twitter fa-2x"></i></a>
    			<a href="#"><i class="fa fa-google-plus fa-2x"></i></a>
    		</div>
    	</div>
    </div>
    
    <!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    <div class="modal fade" id="contact" role="dialog">
    	<div class="modal-dialog">
    		<div class="modal-content">
    			<form class="form-horizontal" role="form" method="post" action="contact.php">
    				<div class="modal-header">
                        <h4>Contact</h4>
                            </div>
	    			<div class="modal-body">
    					<div class="form-group">
    						<label for="contact-name" class="col-sm-2 control-label">Name</label>
    						<div class="col-sm-10">
    							<input type="text" class="form-control" id="contact-name" placeholder="First & Last Name" value="<?=$_SESSION['fname']." ".$_SESSION['lname']; ?>" name="name">
    						</div>
    					</div>
    					<div class="form-group">
    						<label for="contact-email" class="col-sm-2 control-label">Email</label>
    						<div class="col-sm-10">
    							<input type="email" class="form-control" value="<?= $_SESSION['email']; ?>" id="contact-email" placeholder="example@domain.com" name="email">
    						</div>
    					</div>
    					<div class="form-group">
    						<label for="contact-subject" class="col-sm-2 control-label">Subject</label>
    						<div class="col-sm-10">
    							<input type="text" class="form-control" id="contact-subject" name="subject">
    						</div>
    					</div>
    					<div class="form-group">
    						<label for="contact-message" class="col-sm-2 control-label">Message</label>
    						<div class="col-sm-10">
    							<textarea class="form-control" rows="4" name="msg"></textarea>
    						</div>
    					</div>
	    			</div>
	    			<div class="modal-footer">
    					<a class="btn btn-default" data-dismiss="modal">Close</a>
    					<button type="submit" class="btn btn-primary">Send</button>
    				</div>
    			</form>
    		</div>
    	</div>
    </div>
    
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.0/jquery.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
  </body>
</html>