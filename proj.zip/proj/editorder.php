<?php
include 'includes/connect.php';
session_start();
if(!isset($_SESSION['email'])){
    echo "<script>alert('Could not access this page.Try again later')</script>";
    header("location:home.php");
}else{
    $oid=$_GET['oid'];
    $query="SELECT * FROM orders where oid='$oid'";
    $result=mysqli_query($conn,$query);
    while($l=mysqli_fetch_array($result)){
        $btype=$l['btype'];
        $units=$l['units'];
        $pname=$l['pname'];
        $datetime=$l['datetime'];
        $hname=$l['hname'];
        $haddress=$l['haddress'];
        $details=$l['details'];
    }
}

?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="bloodbankmanagement.com">
    <meta name="author" content="bloodbank.com">
    <title>Blood Bank Management</title>
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/custom.css" rel="stylesheet">
    <link href="http://netdna.bootstrapcdn.com/font-awesome/4.0.3/css/font-awesome.css" rel="stylesheet">
    <link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css'>
    <link href='http://fonts.googleapis.com/css?family=Oswald' rel='stylesheet' type='text/css'>
  </head>
  <body>
    <!-- Fixed navbar -->
    <div class="navbar navbar-default navbar-fixed-top" role="navigation">
      <div class="container">
        <div class="navbar-header">
          <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
          <a class="navbar-brand" href="#">Blood Bank Management</a>
        </div>
        <div class="navbar-collapse collapse">
          <ul class="nav navbar-nav navbar-right">
            <li><a href="home.php">My Profile</a></li>       
            <li class="active"><a href="order.php">Order</a></li>
            <li><a href="donororder.php">My Orders</a></li>          
            <li><a href="#contact" data-toggle="modal">Contact</a></li>
            <li><a href="logout.php">Logout</a></li>
          </ul>
        </div><!--/.nav-collapse -->
      </div>
    </div>
    <form method="post" class="form-horizontal" role="form" action="editorder1.php">
                <div class="panel panel-default">
                    <div class="panel-heading">
                        <h4>Edit my orders</h4>
                    </div>
                    <div class="panel-body">
                        <div class="form-group">
                            <label class="col-sm-4">Blood Type</label>
                            <div class="col-sm-8">
                                <select name="btype" value="<?= $btype; ?>" class="form-control">
                                    <option value="O+">O+</option>
                                    <option value="O-">O-</option>
                                    <option value="A+">A+</option>
                                    <option value="A-">A-</option>
                                    <option value="B+">B+</option>
                                    <option value="B-">B-</option>
                                    <option value="AB+">AB+</option>
                                    <option value="AB-">AB-</option>
                                </select>
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="col-sm-4">No. of units</label>
                            <div class="col-sm-8">
                                <input type="number" name="units" value="<?= $units; ?>" placeholder="Enter the no. of units required" class="form-control" required="true">
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="col-sm-4">Patient Name</label>
                            <div class="col-sm-8">
                                <input type="text" name="pname" value="<?= $pname; ?>" placeholder="Enter the name of the blood recepient" class="form-control" required="true">
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="col-sm-4">Date & Time</label>
                            <div class="col-sm-8">
                                <input type="datetime" name="datetime" value="<?= $datetime; ?>" placeholder="Enter the date and time on which it is to be delivered         Eg:yyyy-mm-dd hh:mm" class="form-control" required="true">
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="col-sm-4">Hospital name</label>
                            <div class="col-sm-8">
                                <input type="text" name="hname" value="<?= $hname; ?>" placeholder="Enter the name of the hospital to which blood is to be delivered" class="form-control" required="true">
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="col-sm-4">Hospital Address</label>
                            <div class="col-sm-8">
                                <input type="text" name="haddress" value="<?= $haddress; ?>" placeholder="Enter the address of the hospital" class="form-control" required="true">
                             </div>
                        </div>
                        <div class="form-group">
                            <label class="col-sm-4">Any other details</label>
                            <div class="col-sm-8">
                                 <input type="text" name="details" value="<?= $details; ?>" placeholder="" class="form-control">
                            </div>
                        </div>
                    </div>
        </div>
        <input type="hidden" name="oid" value="<?= $oid; ?>">
        <div align="center">
        <button type="submit" class="btn btn-primary">Edit</button>
        </div>
        </form>
     <!-- Fixed footer -->
    <div class="navbar navbar-inverse navbar-fixed-bottom" role="navigation">
    	<div class="container">
    		<div class="navbar-text pull-left">
    			<p>Project by: <b>KIRAN KUMAR.A</b> & <b>KARTHIK.T</b></p>
    		</div>
    		<div class="navbar-text pull-right">
    			<a href="#"><i class="fa fa-facebook-square fa-2x"></i></a>
    			<a href="#"><i class="fa fa-twitter fa-2x"></i></a>
    			<a href="#"><i class="fa fa-google-plus fa-2x"></i></a>
    		</div>
    	</div>
    </div>
    
    <!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    <div class="modal fade" id="contact" role="dialog">
    	<div class="modal-dialog">
    		<div class="modal-content">
    			<form class="form-horizontal" role="form" method=post action="contact.php">
    				<div class="modal-header">
                        <h4>Contact</h4>
                            </div>
	    			<div class="modal-body">
    					<div class="form-group">
    						<label for="contact-name" class="col-sm-2 control-label">Name</label>
    						<div class="col-sm-10">
    							<input type="text" class="form-control" id="contact-name" value="<?= $_SESSION['fname']." ".$_SESSION['lname']; ?>" placeholder="First & Last Name" name="name">
    						</div>
    					</div>
    					<div class="form-group">
    						<label for="contact-email" class="col-sm-2 control-label">Email</label>
    						<div class="col-sm-10">
    							<input type="email" class="form-control" id="contact-email" value="<?= $_SESSION['email']; ?>" placeholder="example@domain.com" name="email">
    						</div>
    					</div>
    					<div class="form-group">
    						<label for="contact-subject" class="col-sm-2 control-label">Subject</label>
    						<div class="col-sm-10">
    							<input type="text" class="form-control" id="contact-subject" name="subject">
    						</div>
    					</div>
    					<div class="form-group">
    						<label for="contact-message" class="col-sm-2 control-label">Message</label>
    						<div class="col-sm-10">
    							<textarea class="form-control" rows="4" name="msg"></textarea>
    						</div>
    					</div>
	    			</div>
	    			<div class="modal-footer">
    					<a class="btn btn-default" data-dismiss="modal">Close</a>
    					<button type="submit" class="btn btn-primary">Send</button>
    				</div>
    			</form>
    		</div>
    	</div>
    </div>
    
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.0/jquery.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
  </body>
</html>